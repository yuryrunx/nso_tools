NSO Tools
-

Tools for fast get information from Cisco NSO


[More example](https://github.com/NSO-developer/nso-5-day-training/blob/master/nso_python_api_examples.py)

# How to use

```python
from nso_tools import NsoTools()

nt = NsoTools()

nt.config.show()                        # return. Информация о конфигурации NSO. Для дебага. 
                                        # TODO: Дописать через геттер сеттер, для конфигурации через один метод.
nt.tools.synk_from(hostname)            # stdout. Синхронизирует NSO устройства от реального девайса. Выведет лог в stdout
nt.tools.get_device_list(keywords)      # return. Вернет список устройств, у которых keywords входит в Hostname 
nt.interfaces.show(hostname)            # stdout. Вернет все интерфейсы на устройстве (hostname)
nt.vrf.show(hostname)                   # stdout. Вернет все VRF на устройстве (hostname)
```


TODO:
- setuptools
- tests
- кроме show() сделать методы для возврата значения а так же формирования excel файла
