# -*- coding: utf-8 -*-

"""
Набот инструментов для работы с NSO
Инструкция в README.md
"""

from nso_tools.settings.config import Config
from nso_tools.nso_sys.tools import Tools
from nso_tools.parsers.interfaces import NsoInterfaceParser
from nso_tools.parsers.vrf import NsoVrfParser
from nso_tools.parsers.nso_utils import NsoUtils

class NsoTools(object):
     
    def __init__(self):
        self.conf = Config()
        
        # Передаем объект для конфигурации внутренних классов
        self.nso_utils = NsoUtils(self.conf) 
        self.interfaces = NsoInterfaceParser(self.conf)
        self.vrf = NsoVrfParser(self.conf)
        self.tools = Tools(self.conf)
        
        
        #print(dir(self))
        

if __name__ == '__main__':
    """ Debug """
    nt = NsoTools()
    #print(dir(nt))
    # ['MSN_11_0005_1', 'MSN_11_0005_2', 'MSN_11_0005_4']
    #nt.tools.synk_from('MSN_11_0005_2')
    print(nt.tools.get_device_list('MSN_11'))
    #nt.interfaces.show('MSN_11_0005_1')
    #nt.vrf.show('MSN_77_100040_31')